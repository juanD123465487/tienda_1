# Decisiones técnicas iniciales

- **Backend:** Fastify 5 + TypeScript en Node.js 20+.
- **Base de datos:** PostgreSQL 15+ local.
- **Acceso a datos:** paquete `pg` y SQL versionado; no se incorpora un ORM en esta fase.
- **Validación:** Zod para configuración; la validación de las futuras rutas de negocio se implementará con cada módulo.
- **Dinero:** campos de importes en COP almacenados como `BIGINT` (pesos enteros). Cantidades de inventario usan `NUMERIC(14,3)` para permitir unidades fraccionarias como kg/libra. La forma de redondear los subtotales con cantidades fraccionarias deberá definirse y probarse antes del POS real.
- **Dos cajas:** ambas accederán al mismo servidor dentro de la LAN. PostgreSQL no debe exponerse a la red local ni a internet; solo el backend accede a la base de datos.
- **Contingencia:** el esquema deja campos iniciales para identificar origen y operación única, pero la lógica de cola, conflictos y sincronización no está implementada.
- **Nube:** no se configura en esta fase. La arquitectura aprobada ahora es local; una réplica/backup remoto futuro será opcional y deberá proteger datos y credenciales.
- **Seguridad:** CORS se restringe a orígenes configurados; los endpoints de esta fase son solo de lectura. Antes de producción hay que añadir autenticación/autorización, protección de red y pruebas de seguridad.

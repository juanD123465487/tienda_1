# TiendaPOS — Alcance y entrega de la Fase 2

## Objetivo
Preparar una base técnica reproducible para desarrollo local, preservando los prototipos visuales originales.

## Incluido
- Estructura inicial del backend Fastify + TypeScript.
- Configuración validada mediante Zod y variables de entorno.
- Conexión a PostgreSQL mediante `pg`.
- Endpoint de liveness `/health` y endpoint de salud con base de datos `/api/v1/health`.
- Migración inicial SQL con tablas base e índices.
- Script de datos de demostración para roles/permisos, categorías, productos, cajas y movimientos iniciales.
- Docker Compose opcional para PostgreSQL, expuesto solo en loopback (`127.0.0.1`).
- Instrucciones de inicio y configuración.
- Copias sin modificación de `Index.html` y `venta.html` en `prototipos/`.

## No incluido
- Autenticación, sesiones ni autorización efectiva.
- CRUD de productos o proveedores por API.
- Crear, cobrar, anular o sincronizar ventas.
- Descuento transaccional de inventario.
- Modo de contingencia/sincronización implementado.
- Impresión térmica, dashboard con datos reales o reportes.
- Configuración completa de backups automáticos y recuperación.
- Revisión legal definitiva de privacidad o facturación.

## Criterios para aceptar esta fase
1. `npm run typecheck` pasa sin errores.
2. `npm run build` genera el backend compilado.
3. PostgreSQL puede iniciarse localmente.
4. `npm run db:migrate` crea el esquema y se puede ejecutar de nuevo sin volver a aplicar la migración.
5. `npm run db:seed` carga datos de demostración sin duplicarlos al repetirlo.
6. `/health` responde `status: ok` y `/api/v1/health` confirma conexión a PostgreSQL.

La ejecución real de migraciones y endpoints requiere un PostgreSQL local disponible y las dependencias instaladas.

import type { FastifyInstance } from 'fastify';
import { pool } from '../db/pool.js';

export async function healthRoutes(app: FastifyInstance): Promise<void> {
  app.get('/health', async () => ({ status: 'ok', service: 'tiendapos-api' }));

  app.get('/api/v1/health', async (_request, reply) => {
    try {
      const result = await pool.query<{ now: Date }>('SELECT NOW() AS now');
      return {
        status: 'ok',
        service: 'tiendapos-api',
        database: 'connected',
        timestamp: result.rows[0]?.now.toISOString() ?? new Date().toISOString()
      };
    } catch {
      app.log.error('La comprobación de PostgreSQL falló');
      return reply.code(503).send({
        status: 'degraded',
        service: 'tiendapos-api',
        database: 'unavailable'
      });
    }
  });
}

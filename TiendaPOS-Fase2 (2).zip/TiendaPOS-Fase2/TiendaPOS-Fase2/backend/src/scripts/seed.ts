import { pool } from '../db/pool.js';

const client = await pool.connect();
try {
  await client.query('BEGIN');
  await client.query(`
    INSERT INTO roles(code, name, description) VALUES
      ('admin', 'Administrador', 'Rol base para administración del sistema'),
      ('cashier', 'Cajero', 'Rol base para operación de caja')
    ON CONFLICT (code) DO NOTHING
  `);
  await client.query(`
    INSERT INTO permissions(code, description) VALUES
      ('dashboard.read', 'Consultar dashboard'),
      ('pos.operate', 'Operar punto de venta'),
      ('inventory.read', 'Consultar inventario'),
      ('inventory.manage', 'Administrar inventario'),
      ('reports.read', 'Consultar reportes'),
      ('users.manage', 'Administrar usuarios')
    ON CONFLICT (code) DO NOTHING
  `);
  await client.query(`
    INSERT INTO role_permissions(role_id, permission_id)
    SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
    WHERE r.code = 'admin'
    ON CONFLICT DO NOTHING
  `);
  await client.query(`
    INSERT INTO role_permissions(role_id, permission_id)
    SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('dashboard.read', 'pos.operate', 'inventory.read')
    WHERE r.code = 'cashier'
    ON CONFLICT DO NOTHING
  `);
  await client.query(`
    INSERT INTO categories(name, description) VALUES
      ('Abarrotes', 'Productos de despensa; datos de demostración'),
      ('Bebidas', 'Bebidas; datos de demostración'),
      ('Aseo', 'Productos de aseo; datos de demostración')
    ON CONFLICT (name) DO NOTHING
  `);
  await client.query(`
    INSERT INTO products(sku, barcode, name, category_id, unit_code, sale_price_cop, cost_price_cop, stock_quantity, minimum_stock)
    VALUES
      ('DEMO-001', '7700000000011', 'Arroz de demostración 1 kg', (SELECT id FROM categories WHERE name='Abarrotes'), 'unidad', 4500, 3500, 20, 5),
      ('DEMO-002', '7700000000028', 'Gaseosa de demostración 1.5 L', (SELECT id FROM categories WHERE name='Bebidas'), 'unidad', 5000, 3600, 15, 4),
      ('DEMO-003', '7700000000035', 'Jabón de demostración', (SELECT id FROM categories WHERE name='Aseo'), 'unidad', 3200, 2100, 8, 3)
    ON CONFLICT (sku) DO NOTHING
  `);
  await client.query(`
    INSERT INTO registers(code, name) VALUES ('CAJA-1', 'Caja 1'), ('CAJA-2', 'Caja 2')
    ON CONFLICT (code) DO NOTHING
  `);
  await client.query(`
    INSERT INTO inventory_movements(product_id, movement_type, quantity_delta, unit_cost_cop, source_type, notes)
    SELECT p.id, 'opening', p.stock_quantity, p.cost_price_cop, 'seed', 'Stock ficticio inicial de desarrollo'
    FROM products p WHERE p.sku LIKE 'DEMO-%'
      AND NOT EXISTS (SELECT 1 FROM inventory_movements m WHERE m.product_id = p.id AND m.source_type = 'seed')
  `);
  await client.query('COMMIT');
  console.log('Semillas de desarrollo cargadas. No son inventario real ni incluyen usuarios con contraseña.');
} catch (error) {
  await client.query('ROLLBACK');
  console.error('Falló la carga de semillas:', error instanceof Error ? error.message : error);
  process.exitCode = 1;
} finally {
  client.release();
  await pool.end();
}

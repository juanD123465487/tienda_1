import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import { env } from './config/env.js';
import { pool } from './db/pool.js';
import { healthRoutes } from './routes/health.js';

const app = Fastify({
  logger: { level: env.LOG_LEVEL, redact: ['req.headers.authorization', 'req.headers.cookie'] },
  bodyLimit: 1_048_576,
  trustProxy: false
});

await app.register(helmet, { contentSecurityPolicy: false });
await app.register(cors, {
  origin(origin, callback) {
    // Permite herramientas locales sin Origin (curl/health checks); los navegadores deben usar origen permitido.
    if (!origin || env.corsOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Origen no permitido por CORS'), false);
  },
  methods: ['GET', 'HEAD', 'OPTIONS'],
  credentials: false
});
await app.register(healthRoutes);

app.setNotFoundHandler(async (_request, reply) => {
  return reply.code(404).send({ error: 'NOT_FOUND', message: 'La ruta solicitada no existe.' });
});

app.setErrorHandler((error, request, reply) => {
  request.log.error({ err: error }, 'Error de solicitud');
  return reply.code(500).send({ error: 'INTERNAL_SERVER_ERROR', message: 'Ocurrió un error interno.' });
});

const shutdown = async (signal: string) => {
  app.log.info({ signal }, 'Cerrando TiendaPOS API');
  await app.close();
  await pool.end();
  process.exit(0);
};

process.once('SIGINT', () => void shutdown('SIGINT'));
process.once('SIGTERM', () => void shutdown('SIGTERM'));

try {
  await app.listen({ host: env.HOST, port: env.PORT });
} catch (error) {
  app.log.error(error, 'No se pudo iniciar el servidor');
  await pool.end();
  process.exit(1);
}

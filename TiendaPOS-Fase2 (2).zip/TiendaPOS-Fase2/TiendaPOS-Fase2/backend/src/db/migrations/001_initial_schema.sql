CREATE TABLE IF NOT EXISTS roles (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS permissions (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code VARCHAR(80) NOT NULL UNIQUE,
  description TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS users (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  email VARCHAR(254) NOT NULL UNIQUE,
  display_name VARCHAR(120) NOT NULL,
  password_hash TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS categories (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS suppliers (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  tax_id VARCHAR(40),
  phone VARCHAR(40),
  email VARCHAR(254),
  notes TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  sku VARCHAR(80) NOT NULL UNIQUE,
  barcode VARCHAR(80) UNIQUE,
  name VARCHAR(180) NOT NULL,
  description TEXT,
  category_id BIGINT REFERENCES categories(id) ON DELETE SET NULL,
  unit_code VARCHAR(20) NOT NULL DEFAULT 'unidad',
  sale_price_cop BIGINT NOT NULL CHECK (sale_price_cop >= 0),
  cost_price_cop BIGINT NOT NULL DEFAULT 0 CHECK (cost_price_cop >= 0),
  stock_quantity NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  minimum_stock NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (minimum_stock >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS registers (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  code VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cash_shifts (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  register_id BIGINT NOT NULL REFERENCES registers(id) ON DELETE RESTRICT,
  opened_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
  closed_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'reconciled')),
  opening_cash_cop BIGINT NOT NULL DEFAULT 0 CHECK (opening_cash_cop >= 0),
  expected_cash_cop BIGINT CHECK (expected_cash_cop >= 0),
  counted_cash_cop BIGINT CHECK (counted_cash_cop >= 0),
  difference_cop BIGINT,
  opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  closed_at TIMESTAMPTZ,
  notes TEXT,
  CHECK ((status = 'open' AND closed_at IS NULL) OR (status <> 'open' AND closed_at IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_one_open_shift_per_register ON cash_shifts(register_id) WHERE status = 'open';

CREATE TABLE IF NOT EXISTS sales (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  sale_number VARCHAR(60) NOT NULL UNIQUE,
  register_id BIGINT NOT NULL REFERENCES registers(id) ON DELETE RESTRICT,
  shift_id BIGINT REFERENCES cash_shifts(id) ON DELETE RESTRICT,
  cashier_user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'void')),
  subtotal_cop BIGINT NOT NULL CHECK (subtotal_cop >= 0),
  discount_cop BIGINT NOT NULL DEFAULT 0 CHECK (discount_cop >= 0),
  total_cop BIGINT NOT NULL CHECK (total_cop >= 0),
  source VARCHAR(20) NOT NULL DEFAULT 'local' CHECK (source IN ('local', 'contingency', 'synced')),
  client_operation_id UUID UNIQUE,
  sold_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (discount_cop <= subtotal_cop),
  CHECK (total_cop = subtotal_cop - discount_cop)
);
CREATE INDEX IF NOT EXISTS idx_sales_sold_at ON sales(sold_at);
CREATE INDEX IF NOT EXISTS idx_sales_register_status ON sales(register_id, status);

CREATE TABLE IF NOT EXISTS sale_items (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  sale_id BIGINT NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
  product_id BIGINT REFERENCES products(id) ON DELETE SET NULL,
  sku_snapshot VARCHAR(80) NOT NULL,
  product_name_snapshot VARCHAR(180) NOT NULL,
  quantity NUMERIC(14,3) NOT NULL CHECK (quantity > 0),
  unit_price_cop BIGINT NOT NULL CHECK (unit_price_cop >= 0),
  unit_cost_cop BIGINT NOT NULL DEFAULT 0 CHECK (unit_cost_cop >= 0),
  discount_cop BIGINT NOT NULL DEFAULT 0 CHECK (discount_cop >= 0),
  line_total_cop BIGINT NOT NULL CHECK (line_total_cop >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sale_items_sale_id ON sale_items(sale_id);

CREATE TABLE IF NOT EXISTS payments (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  sale_id BIGINT NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
  method VARCHAR(20) NOT NULL CHECK (method IN ('cash', 'nequi', 'daviplata', 'transfer', 'card', 'other')),
  amount_cop BIGINT NOT NULL CHECK (amount_cop > 0),
  reference VARCHAR(120),
  verification_status VARCHAR(20) NOT NULL DEFAULT 'confirmed' CHECK (verification_status IN ('pending', 'confirmed', 'rejected')),
  paid_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_payments_sale_id ON payments(sale_id);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  movement_type VARCHAR(30) NOT NULL CHECK (movement_type IN ('opening', 'entry', 'sale', 'sale_void', 'adjustment', 'return', 'loss')),
  quantity_delta NUMERIC(14,3) NOT NULL CHECK (quantity_delta <> 0),
  unit_cost_cop BIGINT NOT NULL DEFAULT 0 CHECK (unit_cost_cop >= 0),
  source_type VARCHAR(30),
  source_id BIGINT,
  user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_inventory_movements_product_created ON inventory_movements(product_id, created_at DESC);

CREATE TABLE IF NOT EXISTS stock_entries (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  entry_number VARCHAR(60) NOT NULL UNIQUE,
  supplier_id BIGINT REFERENCES suppliers(id) ON DELETE SET NULL,
  created_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'received', 'cancelled')),
  total_cost_cop BIGINT NOT NULL DEFAULT 0 CHECK (total_cost_cop >= 0),
  notes TEXT,
  received_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stock_entry_items (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  entry_id BIGINT NOT NULL REFERENCES stock_entries(id) ON DELETE CASCADE,
  product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  quantity NUMERIC(14,3) NOT NULL CHECK (quantity > 0),
  unit_cost_cop BIGINT NOT NULL CHECK (unit_cost_cop >= 0),
  line_total_cop BIGINT NOT NULL CHECK (line_total_cop >= 0)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id VARCHAR(100),
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_log_created_at ON audit_log(created_at DESC);

CREATE TABLE IF NOT EXISTS schema_migrations (
  version VARCHAR(180) PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

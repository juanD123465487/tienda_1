import pg from 'pg';
import { env } from '../config/env.js';

const { Pool } = pg;
export const pool = new Pool({
  connectionString: env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  application_name: 'tiendapos-backend'
});

pool.on('error', (error) => {
  // Evita filtrar credenciales o datos del negocio en los logs.
  console.error('Error inesperado en una conexión PostgreSQL inactiva:', error.message);
});
